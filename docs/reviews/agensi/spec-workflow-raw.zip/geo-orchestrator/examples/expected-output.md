# Expected fictional demonstration

These are literal acceptance expectations for the bundled synthetic inputs, not product measurements. Actual execution receipts are retained in the repository's TICKET-008 verification record.

- audit: exit 0; 17 pass, 0 fail, 2 unknown; live indexing and schema semantics remain unmeasured.
- aso: exit 0; 9 pass, 0 fail, 2 unknown; semantic claims remain unknown.
- plan: exit 0; one fact-linked opportunity, no research gaps; supplied URLs are not fetched proof.
- visibility: exit 0; 3 attempted, 2 successful, 1 failed; coverage 2/3, mention/citation rates 1/2, Other Journal count 1, recommendation rate null. Retained bytes must match examples/responses.jsonl. These are explicitly fictional records.
