# Sources and limits

A baseline of local evidence, not live indexing, analytics, store approval or growth measurement.

Consult the [pinned primary-source review](https://github.com/tsm0420/geo-growth-engine/blob/c1ae2d9c626c93d8bbbe7c9dc93f3bc81cfeb031/docs/sources.md) when changing platform rules; it records its actual review dates. Read supplied fact sources before approving claims. The fictional example domains/answers are demonstration data, not actual product or provider evidence.

Local reports preserve failed checks and explicit unknowns. Search access, training permission, indexing and measured AI visibility are separate concepts. Any later product edits, live collection, publishing or paid sampling require the user's applicable scope. Agensi platform delivery and original-author MIT/free eligibility remain pending verification; local extraction is not that verification.
