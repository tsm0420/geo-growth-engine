---
name: geo-content-engine
description: Plan GEO content opportunities from supplied audience questions and sourced product facts, including evidence gaps.
---

Use Node.js 24+, a local shell/filesystem, and the separately installed pinned GEO Growth Engine CLI. This ZIP contains instructions and fictional examples. Read [setup and contracts](references/setup-and-contract.md) to confirm CLI provenance; if unavailable, report the missing prerequisite before claiming findings. For a verified checkout, replace `geo` below with `node /absolute/toolkit/dist/src/cli.js`. No sibling skill is required.

Run GEO Growth Engine's `geo plan --config <config> --output <directory>`. Queries link to explicit product-fact IDs; unsupported queries become research gaps. If the CLI is unavailable, identify the prerequisite.

Read sources before drafting. A supplied source URL is a traceability pointer until inspected. Give each page distinct value and preserve supporting fact IDs. Comparisons need current evidence for both products. Request missing evidence instead of inventing capabilities, prices, testimonials, or demand.

The CLI produces opportunities, not publishable pages or traffic estimates. Explain which supplied query each opportunity serves. Keep later edits and PRs within the user's authorized scope. Avoid keyword-only page variants.
