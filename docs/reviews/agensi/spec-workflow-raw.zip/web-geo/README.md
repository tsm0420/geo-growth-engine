# Web GEO Audit: Inspect Your HTML Export

Inspect exported HTML metadata, canonical/sitemap coverage and duplicates, crawler files and JSON-LD syntax.

Status: free listing candidate; no Agensi account, submission, scan approval or live listing is established. The public MIT toolkit stays available.

Requires Node.js 24+, local shell/filesystem access and the separately installed pinned CLI. This instruction ZIP contains no CLI or binaries and requires no sibling skill. Use the [setup and contracts](references/setup-and-contract.md), [fictional expected outputs](examples/expected-output.md) and [sources and limits](references/sources-and-limits.md).

No deployed crawl, JavaScript/CSS rendering, HTTP/WAF inspection, schema semantics or indexing/ranking measurement.

Source: [c1ae2d9c626c93d8bbbe7c9dc93f3bc81cfeb031](https://github.com/tsm0420/geo-growth-engine/tree/c1ae2d9c626c93d8bbbe7c9dc93f3bc81cfeb031); [support/issues](https://github.com/tsm0420/geo-growth-engine/issues); [MIT notice](LICENSE). Package instructions retain the original source skill body and add only the disclosed prerequisite/reference paragraph. No hidden installation, account access or data transmission occurs in the core commands.
