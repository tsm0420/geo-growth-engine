---
name: web-geo
description: Review a website or SaaS public HTML export for metadata, crawler rules, canonical URLs, sitemap coverage and duplicates, and JSON-LD syntax.
---

Use Node.js 24+, a local shell/filesystem, and the separately installed pinned GEO Growth Engine CLI. This ZIP contains instructions and fictional examples. Read [setup and contracts](references/setup-and-contract.md) to confirm CLI provenance; if unavailable, report the missing prerequisite before claiming findings. For a verified checkout, replace `geo` below with `node /absolute/toolkit/dist/src/cli.js`. No sibling skill is required.

Run GEO Growth Engine's `geo audit --config <config> --output <directory>` against the actual build output. If the CLI or export is missing, identify the prerequisite. The command reads local files; it does not crawl deployment or execute JavaScript.

Inspect evidence paths before proposing fixes. Preserve intentional canonical and access policies. OAI-SearchBot controls search; GPTBot controls training permission. Googlebot Search access differs from Google-Extended. Consult [OpenAI crawler documentation](https://developers.openai.com/api/docs/bots) and [Google AI features](https://developers.google.com/search/docs/appearance/ai-features) when changing policies.

For `sitemap-duplicates`, inspect `data.sitemap` counts and one-based positions. Identity uses exact XML-decoded, trimmed text without URL normalization. Duplicates fail with exit 1; unsupported or missing sitemap input leaves this check unknown. Propose retaining one intended canonical entry and rebuilding the export; duplicate findings do not establish indexing or ranking effects.

JSON-LD parsing proves syntax only. Verify product facts and visible content before proposing structured data. llms.txt is optional. Rerun the product's build and audit after authorized fixes. Live HTTP, WAF, rendering, indexing, and ranking remain unmeasured until observed separately.
