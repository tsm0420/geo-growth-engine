# Expected fictional demonstration

These are literal acceptance expectations for the bundled synthetic inputs, not product measurements. Actual execution receipts are retained in the repository's TICKET-008 verification record.

- audit: exit 0; 17 pass, 0 fail, 2 unknown; live indexing and schema semantics remain unmeasured.
