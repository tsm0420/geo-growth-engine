# Expected fictional demonstration

These are literal acceptance expectations for the bundled synthetic inputs, not product measurements. Actual execution receipts are retained in the repository's TICKET-008 verification record.

- visibility: exit 0; 3 attempted, 2 successful, 1 failed; coverage 2/3, mention/citation rates 1/2, Other Journal count 1, recommendation rate null. Retained bytes must match examples/responses.jsonl. These are explicitly fictional records.
