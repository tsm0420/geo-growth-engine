# Setup and contracts

Pinned toolkit: [c1ae2d9c626c93d8bbbe7c9dc93f3bc81cfeb031](https://github.com/tsm0420/geo-growth-engine/tree/c1ae2d9c626c93d8bbbe7c9dc93f3bc81cfeb031), version 0.1.0-alpha.3 candidate. It is not a tagged release or registry publication. Use a separate checkout at this commit; verify `git rev-parse HEAD`, then build with `npm ci --ignore-scripts` and `npm run build`. Dependency setup uses GitHub/npm network access and belongs to separately authorized installation. The review commands read local inputs and write only the chosen report directory. This package installs no executable or runtime.

Set `GEO_TOOLKIT_DIR` to that checkout's absolute directory and verify `node "$GEO_TOOLKIT_DIR/dist/src/cli.js" --help`. If Node, the CLI, supplied configuration or required workflow input is unavailable, report the prerequisite. Do not replace missing evidence with a measurement. A global `geo` binary is usable only with known matching provenance.

From this extracted skill folder, the fictional demonstration is:

```sh
node "$GEO_TOOLKIT_DIR/dist/src/cli.js" visibility --config examples/config.yaml --input examples/responses.jsonl --output demo-reports
```

Exit 0: completed without failed findings; exit 1: observed failed checks; exit 2: operational/input error. Unknown findings remain unknown even with exit 0. Reusing a directory replaces same-named reports/evidence; retain separate run directories for history. Product facts and query links are supplied claims; source URLs are not fetched verification. The publicDir setting is used by audit only; other workflows do not require a website export.

Input schemas and limits: [pinned configuration guide](https://github.com/tsm0420/geo-growth-engine/blob/c1ae2d9c626c93d8bbbe7c9dc93f3bc81cfeb031/docs/configuration.md). Public source and its MIT licence remain available independently. This ZIP and its local tests do not establish Agensi scan approval, authenticated reference delivery, agent triggering or live listing availability.
