# visibility report

**FICTIONAL EXAMPLE — not a product measurement.**

Generated: 2026-10-17T13:55:46.277Z

Imported user-supplied responses; no API calls or consumer-interface collection. Aggregate rates describe this sample set, not market rankings.

Pass: 0; fail: 0; unknown: 3.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| collection-coverage | unknown | 0/1 successful; 1 collection errors; coverage=0 | Read groups and coverage before comparing rates. Failed attempts are excluded from mention/citation denominators. |
| recommendations | unknown | Mentions were matched; explicit recommendations were not classified. | Inspect raw answers before making recommendation claims. |
| provenance | unknown | Provider, model, surface, locale, timestamps, and answers are supplied by the importer and were not independently verified. | Retain collection receipts and repeat comparable queries before drawing conclusions. |

## Details

```json
{
  "totals": {
    "attempted": 1,
    "successful": 0,
    "failed": 1,
    "coverage": 0,
    "mentionRate": null,
    "citationRate": null,
    "recommendationRate": null,
    "competitors": {
      "Other Journal": 0
    }
  },
  "groups": [
    {
      "provider": "fixture-provider",
      "surface": "fixture-api",
      "model": "fixture-model",
      "locale": "en-GB",
      "attempted": 1,
      "successful": 0,
      "failed": 1,
      "coverage": 0,
      "mentionRate": null,
      "citationRate": null,
      "recommendationRate": null,
      "competitors": {
        "Other Journal": 0
      }
    }
  ],
  "source": "/private/tmp/geo-core-gap-visibility/cases/all-errors/observations.jsonl",
  "evidence": "evidence/responses.jsonl",
  "sha256": "cd3887156bd55ed0df96d928333126f630c050db89168b60f667d3b07aebf202"
}
```
