# visibility report

**FICTIONAL EXAMPLE — not a product measurement.**

Generated: 2026-10-17T13:56:38.695Z

Imported user-supplied responses; no API calls or consumer-interface collection. Aggregate rates describe this sample set, not market rankings.

Pass: 1; fail: 0; unknown: 2.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| collection-coverage | pass | 1/1 successful; 0 collection errors; coverage=1 | Read groups and coverage before comparing rates. Failed attempts are excluded from mention/citation denominators. |
| recommendations | unknown | Mentions were matched; explicit recommendations were not classified. | Inspect raw answers before making recommendation claims. |
| provenance | unknown | Provider, model, surface, locale, timestamps, and answers are supplied by the importer and were not independently verified. | Retain collection receipts and repeat comparable queries before drawing conclusions. |

## Details

```json
{
  "totals": {
    "attempted": 1,
    "successful": 1,
    "failed": 0,
    "coverage": 1,
    "mentionRate": 1,
    "citationRate": 0,
    "recommendationRate": null,
    "competitors": {
      "Other Journal": 0
    }
  },
  "groups": [
    {
      "provider": "fixture-provider",
      "surface": "fixture-api",
      "model": "fixture-model",
      "locale": "en-GB",
      "attempted": 1,
      "successful": 1,
      "failed": 0,
      "coverage": 1,
      "mentionRate": 1,
      "citationRate": 0,
      "recommendationRate": null,
      "competitors": {
        "Other Journal": 0
      }
    }
  ],
  "source": "/private/tmp/geo-core-gap-visibility/cases/crlf-evidence/observations.jsonl",
  "evidence": "evidence/responses.jsonl",
  "sha256": "dc71f1bfd8299f3628203e5be4e3caa42c70ce2f5cdba45c23932b0d41a7d214"
}
```
