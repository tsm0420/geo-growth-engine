# visibility report

**FICTIONAL EXAMPLE — not a product measurement.**

Generated: 2026-10-17T13:55:44.844Z

Imported user-supplied responses; no API calls or consumer-interface collection. Aggregate rates describe this sample set, not market rankings.

Pass: 0; fail: 0; unknown: 3.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| collection-coverage | unknown | 3/4 successful; 1 collection errors; coverage=0.75 | Read groups and coverage before comparing rates. Failed attempts are excluded from mention/citation denominators. |
| recommendations | unknown | Mentions were matched; explicit recommendations were not classified. | Inspect raw answers before making recommendation claims. |
| provenance | unknown | Provider, model, surface, locale, timestamps, and answers are supplied by the importer and were not independently verified. | Retain collection receipts and repeat comparable queries before drawing conclusions. |

## Details

```json
{
  "totals": {
    "attempted": 4,
    "successful": 3,
    "failed": 1,
    "coverage": 0.75,
    "mentionRate": 0.3333333333333333,
    "citationRate": 0.6666666666666666,
    "recommendationRate": null,
    "competitors": {
      "Other Journal": 1
    }
  },
  "groups": [
    {
      "provider": "fixture-provider",
      "surface": "fixture-api",
      "model": "fixture-model",
      "locale": "en-GB",
      "attempted": 4,
      "successful": 3,
      "failed": 1,
      "coverage": 0.75,
      "mentionRate": 0.3333333333333333,
      "citationRate": 0.6666666666666666,
      "recommendationRate": null,
      "competitors": {
        "Other Journal": 1
      }
    }
  ],
  "source": "/private/tmp/geo-core-gap-visibility/cases/baseline/observations.jsonl",
  "evidence": "evidence/responses.jsonl",
  "sha256": "4d0131e5e76735924a8a23a972fbaf170e139583acabd5b6eae31c1cf9e054d9"
}
```
