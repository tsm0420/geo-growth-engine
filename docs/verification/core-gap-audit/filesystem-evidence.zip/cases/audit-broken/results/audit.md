# audit report

**FICTIONAL EXAMPLE — not a product measurement.**

Generated: 2026-10-17T13:56:26.353Z

local export: /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public; no network requests or browser execution

Pass: 10; fail: 7; unknown: 2.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| robots-file | pass | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/robots.txt | Review intentional access policy. |
| sitemap | pass | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/sitemap.xml: 1 locations; direct urlset required | Supply a direct sitemap urlset for this export; sitemap indexes are not expanded. |
| sitemap-duplicates | pass | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/sitemap.xml: 1 entries; 1 unique URLs; 0 duplicate entries | Retain one intended canonical entry per URL and rebuild the export. |
| index.html:title | fail | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/index.html: missing title | Provide one descriptive title. |
| index.html:description | fail | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/index.html: missing description | Provide a meaningful description. |
| index.html:open-graph | fail | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/index.html: og:title and og:description presence | Supply truthful social metadata. |
| index.html:heading | pass | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/index.html: 1 H1 elements | Use a descriptive page heading. |
| index.html:readable-text | pass | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/index.html: 4 non-script text characters in HTML | Include public content in the exported HTML. CSS visibility is not evaluated. |
| index.html:index-directive | fail | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/index.html: noindex | Remove noindex only if this page is intended for indexing. HTTP headers are unmeasured. |
| index.html:canonical | fail | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/index.html: https://foreign.example/ | Provide one absolute canonical URL on the configured origin. |
| index.html:sitemap-coverage | pass | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/index.html: https://example.com/ in /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/sitemap.xml | Add the intended canonical URL to the direct sitemap. |
| index.html:crawler.Googlebot | fail | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/robots.txt: Googlebot at inferred export URL https://example.com/; allowed=false; deployment routes unverified | Review search access separately from training permissions. |
| index.html:crawler.OAI-SearchBot | pass | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/robots.txt: OAI-SearchBot at inferred export URL https://example.com/; allowed=true; deployment routes unverified | Review search access separately from training permissions. |
| index.html:training.GPTBot | pass | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/robots.txt: training policy allowed=false; informational only | Preserve the owner's training policy; it is not a search eligibility check. |
| index.html:training.Google-Extended | pass | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/robots.txt: training policy allowed=false; informational only | Preserve the owner's training policy; it is not a search eligibility check. |
| index.html:jsonld-syntax.1 | fail | /private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/index.html: JSON parse failed | Repair JSON syntax; then validate the actual schema and visible claims. |
| schema-semantics | unknown | JSON parsing does not establish Schema.org validity or rich-result eligibility. | Use the applicable schema and search validation tools. |
| live-indexing | unknown | Only local HTML/crawler files were read. HTTP status, headers, WAF, JavaScript rendering, indexing, rankings, and citations were not measured. | Inspect deployment and supported search tools separately. |
| llms-txt | pass | Optional llms.txt absent; no readiness penalty. | Treat as an optional experiment. |

## Details

```json
{
  "config": "/private/tmp/geo-core-gap-filesystem/cases/audit-broken/.geo/config.yaml",
  "files": [
    "/private/tmp/geo-core-gap-filesystem/cases/audit-broken/public/index.html"
  ],
  "sitemap": {
    "entries": 1,
    "uniqueUrls": 1,
    "duplicateEntries": 0,
    "duplicates": []
  }
}
```
