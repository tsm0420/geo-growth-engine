# plan report

User-supplied product artifacts.

Generated: 2026-10-17T13:55:40.074Z

Supplied questions and fact references only; no traffic estimates or automatic publication.

Pass: 0; fail: 0; unknown: 3.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| a | unknown | /private/tmp/geo-core-gap-content/probes/plan-missing-source/queries.yaml: Does it work offline?; priority 1; offline: no source; sources not independently verified | Research this gap before drafting product claims. |
| c | unknown | /private/tmp/geo-core-gap-content/probes/plan-missing-source/queries.yaml: Does it have sync?; priority 1; no evidence; sources not independently verified | Research this gap before drafting product claims. |
| b | unknown | /private/tmp/geo-core-gap-content/probes/plan-missing-source/queries.yaml: How can I save notes?; priority 2; notes: no source; sources not independently verified | Research this gap before drafting product claims. |

## Details

```json
{
  "opportunities": [],
  "researchGaps": [
    {
      "queryId": "a",
      "query": "Does it work offline?",
      "reason": "A linked fact has no source."
    },
    {
      "queryId": "c",
      "query": "Does it have sync?",
      "reason": "No supporting product fact linked."
    },
    {
      "queryId": "b",
      "query": "How can I save notes?",
      "reason": "A linked fact has no source."
    }
  ]
}
```
