# plan report

User-supplied product artifacts.

Generated: 2026-10-17T13:55:28.248Z

Supplied questions and fact references only; no traffic estimates or automatic publication.

Pass: 1; fail: 0; unknown: 2.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| a | unknown | /private/tmp/geo-core-gap-content/probes/plan-sourced-and-gaps/queries.yaml: Does it work offline?; priority 1; offline: no source; sources not independently verified | Research this gap before drafting product claims. |
| c | unknown | /private/tmp/geo-core-gap-content/probes/plan-sourced-and-gaps/queries.yaml: Does it have sync?; priority 1; no evidence; sources not independently verified | Research this gap before drafting product claims. |
| b | pass | /private/tmp/geo-core-gap-content/probes/plan-sourced-and-gaps/queries.yaml: How can I save notes?; priority 2; notes: https://example.com/features/notes; sources not independently verified | Inspect sources and create distinct, useful content only when authorized. |

## Details

```json
{
  "opportunities": [
    {
      "queryId": "b",
      "query": "How can I save notes?",
      "intent": "use-case",
      "priority": 2,
      "facts": [
        {
          "id": "notes",
          "claim": "Save daily notes.",
          "source": "https://example.com/features/notes"
        }
      ]
    }
  ],
  "researchGaps": [
    {
      "queryId": "a",
      "query": "Does it work offline?",
      "reason": "A linked fact has no source."
    },
    {
      "queryId": "c",
      "query": "Does it have sync?",
      "reason": "No supporting product fact linked."
    }
  ]
}
```
