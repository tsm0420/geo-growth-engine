# aso report

User-supplied product artifacts.

Generated: 2026-10-17T13:55:30.399Z

Local supplied store metadata; no store account access or publishing.

Pass: 2; fail: 7; unknown: 2.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| ios.name | fail | /private/tmp/geo-core-gap-content/probes/aso-over-all-limits/product.yaml; en-GB; 31 Unicode code points; accepted range 2-30; https://developer.apple.com/help/app-store-connect/reference/app-information/app-information/ | Review the field in the store console; the CLI checks length, not policy acceptance. |
| ios.subtitle | fail | /private/tmp/geo-core-gap-content/probes/aso-over-all-limits/product.yaml; en-GB; 31 Unicode code points; accepted range 1-30; https://developer.apple.com/help/app-store-connect/reference/app-information/app-information/ | Review the field in the store console; the CLI checks length, not policy acceptance. |
| ios.keywords | fail | /private/tmp/geo-core-gap-content/probes/aso-over-all-limits/product.yaml; en-GB; 101 UTF-8 bytes; accepted range 1-100; https://developer.apple.com/help/app-store-connect/reference/app-information/platform-version-information/ | Review the field in the store console; the CLI checks length, not policy acceptance. |
| ios.description | fail | /private/tmp/geo-core-gap-content/probes/aso-over-all-limits/product.yaml; en-GB; 4001 Unicode code points; accepted range 1-4000; https://developer.apple.com/help/app-store-connect/reference/app-information/platform-version-information/ | Review the field in the store console; the CLI checks length, not policy acceptance. |
| ios.fact-references | pass | /private/tmp/geo-core-gap-content/probes/aso-over-all-limits/product.yaml: supplied references notes -&gt; https://example.com/features/notes; sources not fetched | Inspect the referenced evidence before approving claims. |
| ios.semantic-claims | unknown | Text-to-fact consistency, screenshots, localization quality, conversion, and store acceptance were not verified. | Review every capability, price, and comparison against source evidence; inspect actual console and image artifacts. |
| android.title | fail | /private/tmp/geo-core-gap-content/probes/aso-over-all-limits/product.yaml; en-GB; 31 Unicode code points; accepted range 1-30; https://support.google.com/googleplay/android-developer/answer/9859152?hl=en | Review the field in the store console; the CLI checks length, not policy acceptance. |
| android.shortDescription | fail | /private/tmp/geo-core-gap-content/probes/aso-over-all-limits/product.yaml; en-GB; 81 Unicode code points; accepted range 1-80; https://support.google.com/googleplay/android-developer/answer/9859152?hl=en | Review the field in the store console; the CLI checks length, not policy acceptance. |
| android.fullDescription | fail | /private/tmp/geo-core-gap-content/probes/aso-over-all-limits/product.yaml; en-GB; 4001 Unicode code points; accepted range 1-4000; https://support.google.com/googleplay/android-developer/answer/9859152?hl=en | Review the field in the store console; the CLI checks length, not policy acceptance. |
| android.fact-references | pass | /private/tmp/geo-core-gap-content/probes/aso-over-all-limits/product.yaml: supplied references notes -&gt; https://example.com/features/notes; sources not fetched | Inspect the referenced evidence before approving claims. |
| android.semantic-claims | unknown | Text-to-fact consistency, screenshots, localization quality, conversion, and store acceptance were not verified. | Review every capability, price, and comparison against source evidence; inspect actual console and image artifacts. |
