# plan report

User-supplied product artifacts.

Generated: 2026-10-17T13:55:33.166Z

Supplied questions and fact references only; no traffic estimates or automatic publication.

Pass: 3; fail: 0; unknown: 0.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| a | pass | /private/tmp/geo-core-gap-content/probes/plan-priority-and-id-sort/queries.yaml: Question a?; priority 1; notes: https://example.com/features/notes; sources not independently verified | Inspect sources and create distinct, useful content only when authorized. |
| b | pass | /private/tmp/geo-core-gap-content/probes/plan-priority-and-id-sort/queries.yaml: Question b?; priority 1; notes: https://example.com/features/notes; sources not independently verified | Inspect sources and create distinct, useful content only when authorized. |
| z | pass | /private/tmp/geo-core-gap-content/probes/plan-priority-and-id-sort/queries.yaml: Question z?; priority 2; notes: https://example.com/features/notes; sources not independently verified | Inspect sources and create distinct, useful content only when authorized. |

## Details

```json
{
  "opportunities": [
    {
      "queryId": "a",
      "query": "Question a?",
      "intent": "faq",
      "priority": 1,
      "facts": [
        {
          "id": "notes",
          "claim": "Save daily notes.",
          "source": "https://example.com/features/notes"
        }
      ]
    },
    {
      "queryId": "b",
      "query": "Question b?",
      "intent": "faq",
      "priority": 1,
      "facts": [
        {
          "id": "notes",
          "claim": "Save daily notes.",
          "source": "https://example.com/features/notes"
        }
      ]
    },
    {
      "queryId": "z",
      "query": "Question z?",
      "intent": "faq",
      "priority": 2,
      "facts": [
        {
          "id": "notes",
          "claim": "Save daily notes.",
          "source": "https://example.com/features/notes"
        }
      ]
    }
  ],
  "researchGaps": []
}
```
