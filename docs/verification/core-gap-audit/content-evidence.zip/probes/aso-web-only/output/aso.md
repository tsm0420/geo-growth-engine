# aso report

User-supplied product artifacts.

Generated: 2026-10-17T13:55:28.891Z

Local supplied store metadata; no store account access or publishing.

Pass: 0; fail: 0; unknown: 1.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| app-listings | unknown | No mobile platform or listing configured. | No ASO measurement is available for this product. |
