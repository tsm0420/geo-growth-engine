# aso report

User-supplied product artifacts.

Generated: 2026-10-17T13:55:28.543Z

Local supplied store metadata; no store account access or publishing.

Pass: 0; fail: 0; unknown: 2.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| ios.listing | unknown | /private/tmp/geo-core-gap-content/probes/aso-listings-omitted/product.yaml: no ios listing supplied | Supply listing text and locale when available. |
| android.listing | unknown | /private/tmp/geo-core-gap-content/probes/aso-listings-omitted/product.yaml: no android listing supplied | Supply listing text and locale when available. |
