# plan report

**FICTIONAL EXAMPLE — not a product measurement.**

Generated: 2026-10-17T15:17:02.480Z

Supplied questions and fact references only; no traffic estimates or automatic publication.

Pass: 0; fail: 0; unknown: 2.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| private-storage | unknown | /private/tmp/geo-evaluate008/reports/forward/inputs/queries.json: How can I store private notes?; priority 1; private-notes: no source; sources not independently verified | Research this gap before drafting product claims. |
| offline-sync | unknown | /private/tmp/geo-evaluate008/reports/forward/inputs/queries.json: Can it sync offline?; priority 2; no evidence; sources not independently verified | Research this gap before drafting product claims. |

## Details

```json
{
  "opportunities": [],
  "researchGaps": [
    {
      "queryId": "private-storage",
      "query": "How can I store private notes?",
      "reason": "A linked fact has no source."
    },
    {
      "queryId": "offline-sync",
      "query": "Can it sync offline?",
      "reason": "No supporting product fact linked."
    }
  ]
}
```
