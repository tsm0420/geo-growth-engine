# audit report

**FICTIONAL EXAMPLE — not a product measurement.**

Generated: 2026-10-17T15:17:01.653Z

local export: /private/tmp/geo-evaluate008/reports/forward/inputs/public; no network requests or browser execution

Pass: 13; fail: 3; unknown: 3.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| robots-file | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/robots.txt | Review intentional access policy. |
| sitemap | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/sitemap.xml: 2 locations; direct urlset required | Supply a direct sitemap urlset for this export; sitemap indexes are not expanded. |
| sitemap-duplicates | fail | /private/tmp/geo-evaluate008/reports/forward/inputs/public/sitemap.xml: 2 entries; 1 unique URLs; 1 duplicate entries; https://orchid.invalid/ occurs 2 times at positions 1, 2 | Retain one intended canonical entry per URL and rebuild the export. |
| index.html:title | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/index.html: Orchid Notes fictional evaluation | Provide one descriptive title. |
| index.html:description | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/index.html: Fictional notes fixture | Provide a meaningful description. |
| index.html:open-graph | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/index.html: og:title and og:description presence | Supply truthful social metadata. |
| index.html:heading | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/index.html: 1 H1 elements | Use a descriptive page heading. |
| index.html:readable-text | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/index.html: 63 non-script text characters in HTML | Include public content in the exported HTML. CSS visibility is not evaluated. |
| index.html:index-directive | fail | /private/tmp/geo-evaluate008/reports/forward/inputs/public/index.html: noindex | Remove noindex only if this page is intended for indexing. HTTP headers are unmeasured. |
| index.html:canonical | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/index.html: https://orchid.invalid/ | Provide one absolute canonical URL on the configured origin. |
| index.html:sitemap-coverage | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/index.html: https://orchid.invalid/ in /private/tmp/geo-evaluate008/reports/forward/inputs/public/sitemap.xml | Add the intended canonical URL to the direct sitemap. |
| index.html:crawler.Googlebot | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/robots.txt: Googlebot at inferred export URL https://orchid.invalid/; allowed=true; deployment routes unverified | Review search access separately from training permissions. |
| index.html:crawler.OAI-SearchBot | fail | /private/tmp/geo-evaluate008/reports/forward/inputs/public/robots.txt: OAI-SearchBot at inferred export URL https://orchid.invalid/; allowed=false; deployment routes unverified | Review search access separately from training permissions. |
| index.html:training.GPTBot | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/robots.txt: training policy allowed=false; informational only | Preserve the owner's training policy; it is not a search eligibility check. |
| index.html:training.Google-Extended | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/public/robots.txt: training policy allowed=true; informational only | Preserve the owner's training policy; it is not a search eligibility check. |
| index.html:jsonld-syntax | unknown | /private/tmp/geo-evaluate008/reports/forward/inputs/public/index.html: no JSON-LD supplied | Add structured data only when appropriate and supported by visible facts. |
| schema-semantics | unknown | JSON parsing does not establish Schema.org validity or rich-result eligibility. | Use the applicable schema and search validation tools. |
| live-indexing | unknown | Only local HTML/crawler files were read. HTTP status, headers, WAF, JavaScript rendering, indexing, rankings, and citations were not measured. | Inspect deployment and supported search tools separately. |
| llms-txt | pass | Optional llms.txt absent; no readiness penalty. | Treat as an optional experiment. |

## Details

```json
{
  "config": "/private/tmp/geo-evaluate008/reports/forward/inputs/config.json",
  "files": [
    "/private/tmp/geo-evaluate008/reports/forward/inputs/public/index.html"
  ],
  "sitemap": {
    "entries": 2,
    "uniqueUrls": 1,
    "duplicateEntries": 1,
    "duplicates": [
      {
        "url": "https://orchid.invalid/",
        "occurrences": 2,
        "positions": [
          1,
          2
        ]
      }
    ]
  }
}
```
