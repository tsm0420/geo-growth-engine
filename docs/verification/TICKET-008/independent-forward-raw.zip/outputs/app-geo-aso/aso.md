# aso report

**FICTIONAL EXAMPLE — not a product measurement.**

Generated: 2026-10-17T15:17:01.796Z

Local supplied store metadata; no store account access or publishing.

Pass: 3; fail: 1; unknown: 2.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| ios.name | fail | /private/tmp/geo-evaluate008/reports/forward/inputs/product.json; en-GB; 1 Unicode code points; accepted range 2-30; https://developer.apple.com/help/app-store-connect/reference/app-information/app-information/ | Review the field in the store console; the CLI checks length, not policy acceptance. |
| ios.subtitle | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/product.json; en-GB; 13 Unicode code points; accepted range 1-30; https://developer.apple.com/help/app-store-connect/reference/app-information/app-information/ | Review the field in the store console; the CLI checks length, not policy acceptance. |
| ios.keywords | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/product.json; en-GB; 13 UTF-8 bytes; accepted range 1-100; https://developer.apple.com/help/app-store-connect/reference/app-information/platform-version-information/ | Review the field in the store console; the CLI checks length, not policy acceptance. |
| ios.description | pass | /private/tmp/geo-evaluate008/reports/forward/inputs/product.json; en-GB; 20 Unicode code points; accepted range 1-4000; https://developer.apple.com/help/app-store-connect/reference/app-information/platform-version-information/ | Review the field in the store console; the CLI checks length, not policy acceptance. |
| ios.fact-references | unknown | /private/tmp/geo-evaluate008/reports/forward/inputs/product.json: supplied references private-notes -&gt; missing source; sources not fetched | Inspect the referenced evidence before approving claims. |
| ios.semantic-claims | unknown | Text-to-fact consistency, screenshots, localization quality, conversion, and store acceptance were not verified. | Review every capability, price, and comparison against source evidence; inspect actual console and image artifacts. |
