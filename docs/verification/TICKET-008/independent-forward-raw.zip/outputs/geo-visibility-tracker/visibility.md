# visibility report

**FICTIONAL EXAMPLE — not a product measurement.**

Generated: 2026-10-17T15:17:02.074Z

Imported user-supplied responses; no API calls or consumer-interface collection. Aggregate rates describe this sample set, not market rankings.

Pass: 0; fail: 0; unknown: 3.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| collection-coverage | unknown | 2/3 successful; 1 collection errors; coverage=0.6666666666666666 | Read groups and coverage before comparing rates. Failed attempts are excluded from mention/citation denominators. |
| recommendations | unknown | Mentions were matched; explicit recommendations were not classified. | Inspect raw answers before making recommendation claims. |
| provenance | unknown | Provider, model, surface, locale, timestamps, and answers are supplied by the importer and were not independently verified. | Retain collection receipts and repeat comparable queries before drawing conclusions. |

## Details

```json
{
  "totals": {
    "attempted": 3,
    "successful": 2,
    "failed": 1,
    "coverage": 0.6666666666666666,
    "mentionRate": 0.5,
    "citationRate": 0.5,
    "recommendationRate": null,
    "competitors": {
      "Maple Notes": 1
    }
  },
  "groups": [
    {
      "provider": "fictional-evaluation",
      "surface": "api-fixture",
      "model": "none",
      "locale": "en-GB",
      "attempted": 2,
      "successful": 1,
      "failed": 1,
      "coverage": 0.5,
      "mentionRate": 1,
      "citationRate": 1,
      "recommendationRate": null,
      "competitors": {
        "Maple Notes": 0
      }
    },
    {
      "provider": "fictional-evaluation",
      "surface": "consumer-fixture",
      "model": "none",
      "locale": "en-GB",
      "attempted": 1,
      "successful": 1,
      "failed": 0,
      "coverage": 1,
      "mentionRate": 0,
      "citationRate": 0,
      "recommendationRate": null,
      "competitors": {
        "Maple Notes": 1
      }
    }
  ],
  "source": "/private/tmp/geo-evaluate008/reports/forward/inputs/responses.jsonl",
  "evidence": "evidence/responses.jsonl",
  "sha256": "d418039d42c4dff94397abdb9b1d984865c366c72abef3aa18c8fdb35cdf7d5c"
}
```
