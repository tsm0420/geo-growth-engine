# audit report

**FICTIONAL EXAMPLE — not a product measurement.**

Generated: 2026-10-17T14:27:59.762Z

local export: /private/tmp/geo-xml-research/cli-cases/malformed-hex/public; no network requests or browser execution

Pass: 14; fail: 2; unknown: 3.

| Check | Status | Evidence | Next action |
| --- | --- | --- | --- |
| robots-file | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/robots.txt | Review intentional access policy. |
| sitemap | fail | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/sitemap.xml: invalid or unsupported XML | Use well-formed sitemap XML without DTDs or custom entities. |
| sitemap-duplicates | unknown | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/sitemap.xml: duplicate URLs unmeasured without a supported sitemap | Provide a valid direct urlset on the configured origin, then rerun. |
| index.html:title | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/index.html: Example Journal — fictional toolkit fixture | Provide one descriptive title. |
| index.html:description | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/index.html: Fictional sample: save daily journal entries. | Provide a meaningful description. |
| index.html:open-graph | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/index.html: og:title and og:description presence | Supply truthful social metadata. |
| index.html:heading | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/index.html: 1 H1 elements | Use a descriptive page heading. |
| index.html:readable-text | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/index.html: 124 non-script text characters in HTML | Include public content in the exported HTML. CSS visibility is not evaluated. |
| index.html:index-directive | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/index.html: no restrictive HTML meta directive observed | Remove noindex only if this page is intended for indexing. HTTP headers are unmeasured. |
| index.html:canonical | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/index.html: https://example.com/ | Provide one absolute canonical URL on the configured origin. |
| index.html:sitemap-coverage | fail | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/index.html: https://example.com/ in /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/sitemap.xml | Add the intended canonical URL to the direct sitemap. |
| index.html:crawler.Googlebot | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/robots.txt: Googlebot at inferred export URL https://example.com/; allowed=true; deployment routes unverified | Review search access separately from training permissions. |
| index.html:crawler.OAI-SearchBot | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/robots.txt: OAI-SearchBot at inferred export URL https://example.com/; allowed=true; deployment routes unverified | Review search access separately from training permissions. |
| index.html:training.GPTBot | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/robots.txt: training policy allowed=false; informational only | Preserve the owner's training policy; it is not a search eligibility check. |
| index.html:training.Google-Extended | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/robots.txt: training policy allowed=false; informational only | Preserve the owner's training policy; it is not a search eligibility check. |
| index.html:jsonld-syntax.1 | pass | /private/tmp/geo-xml-research/cli-cases/malformed-hex/public/index.html: JSON-LD parses as an object or array | Review structured-data semantics separately. |
| schema-semantics | unknown | JSON parsing does not establish Schema.org validity or rich-result eligibility. | Use the applicable schema and search validation tools. |
| live-indexing | unknown | Only local HTML/crawler files were read. HTTP status, headers, WAF, JavaScript rendering, indexing, rankings, and citations were not measured. | Inspect deployment and supported search tools separately. |
| llms-txt | pass | Optional llms.txt absent; no readiness penalty. | Treat as an optional experiment. |

## Details

```json
{
  "config": "/private/tmp/geo-xml-research/cli-cases/malformed-hex/.geo/config.yaml",
  "files": [
    "/private/tmp/geo-xml-research/cli-cases/malformed-hex/public/index.html"
  ],
  "sitemap": null
}
```
